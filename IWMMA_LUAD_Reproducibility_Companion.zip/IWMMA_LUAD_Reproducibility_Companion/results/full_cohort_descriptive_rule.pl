% Learned Horn clauses for LUAD tumour classification

tumor(X) :- high(X,P), up_in_tumor(P), high_shap(P).
