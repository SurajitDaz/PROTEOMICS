"""Verify the frozen manuscript results without the raw CPTAC inputs."""
import csv
from math import isclose
from pathlib import Path

from sklearn.metrics import (accuracy_score, average_precision_score,
                             balanced_accuracy_score, f1_score, precision_score,
                             recall_score, roc_auc_score)

root = Path(__file__).resolve().parent / 'results'

def load(name):
    with (root / (name + '.csv')).open(newline='') as handle:
        return list(csv.DictReader(handle))

cohorts = []
for name, pred_col in [('nested_ml', 'oof_prediction'),
                       ('fol_ilp', 'FOL_ILP_oof_prediction')]:
    rows = load(name + '_oof_predictions')
    cohort = {r['Sample_ID']: (r['Patient_ID'], r['y_true']) for r in rows}
    assert len(rows) == len(cohort) == 213
    assert len({p for p,t in cohort.values()}) == 111
    cohorts.append(cohort)
    y = [int(r['y_true']) for r in rows]
    yhat = [int(r[pred_col]) for r in rows]
    metrics = {'Accuracy':accuracy_score(y,yhat),
               'Balanced Accuracy':balanced_accuracy_score(y,yhat),
               'Precision':precision_score(y,yhat), 'F1':f1_score(y,yhat)}
    if name == 'nested_ml':
        probabilities = [float(r['oof_probability']) for r in rows]
        metrics.update({'ROC-AUC':roc_auc_score(y,probabilities),
                        'PR-AUC':average_precision_score(y,probabilities),
                        'Sensitivity':recall_score(y,yhat),
                        'Specificity':recall_score(y,yhat,pos_label=0)})
    else:
        metrics['Recall'] = recall_score(y,yhat)
    saved = {r['Metric']:float(r['Value']) for r in load(name+'_metrics')}
    for metric, value in metrics.items():
        assert isclose(value, saved[metric], abs_tol=1e-10), (name, metric)
    print(name, metrics)
assert cohorts[0] == cohorts[1]
rows = load('paired_differential_proteomics')
assert len(rows) == 9518
effects = [float(r['Mean_log_ratio_difference']) for r in rows if float(r['FDR']) < .05]
assert (sum(e>=1 for e in effects), sum(e<=-1 for e in effects)) == (40,338)
rows = load('full_cohort_descriptive_rule_predictions_replayed')
assert len(rows) == 213
assert sum(r['y_true']=='1' and r['descriptive_rule_prediction']=='1' for r in rows)==111
assert sum(r['y_true']=='0' and r['descriptive_rule_prediction']=='1' for r in rows)==1
print('Verified: 378 differential proteins and descriptive rule with 111 true positives and one false positive.')
