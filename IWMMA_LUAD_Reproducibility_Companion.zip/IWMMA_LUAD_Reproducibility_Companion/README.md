# CPTAC-LUAD reproducibility companion for IWMMA 2026

## Verify the reported results
Install scikit-learn and run `python verify_results.py` from the extracted package. The script checks pooled metrics against stored sample predictions, verifies that both predictors cover the same sample cohort, and verifies the thresholded differential counts and full-cohort rule counts. The historic CSV label PR-AUC denotes average precision. The full-cohort rule replay is descriptive.

## Rerun from inputs
Open analysis/manuscript_analysis.ipynb in Colab. Place the four inputs named in results/run_manifest.json into BASE_DIR/0_Dataset or upload the previously supplied Proteom_Updated.zip when prompted. The source study is PDC000153 (https://proteomic.datacommons.cancer.gov/pdc/study/PDC000153). Use the exact biospecimen manifest from the supplied project archive. The four source files in that archive matched all recorded hashes when this package was assembled. This companion requires those inputs separately.

Set BASE_DIR to a clean project directory on Drive and run all cells. Compare the input hashes and package versions with results/run_manifest.json. The notebook records the actual runtime environment, which can vary with Colab, and writes derived outputs to FOL_ILP/OUTPUT. Compare the corrected pooled CSVs and predictions with the corresponding frozen files in results/. The manuscript analysis has separate grouped runs for the sparse classifier and FOL/ILP. It is a single-cohort analysis and the rates are not a same-fold ablation.

## Contents and provenance
manuscript.tex is the supplied submission draft. figures/ contains the graphics it references. results/ contains curated outputs from the supplied results package. Full-cohort descriptive-rule evidence also includes a knowledge-base replay, documented in results/full_cohort_rule_replay_note.txt. The notebook represents the original manuscript analysis rather than the subsequent benchmark extension. Only existing manuscript results are represented. The package verification recomputed scores from frozen outputs and does not constitute a fresh end-to-end model rerun.
