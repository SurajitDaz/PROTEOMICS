MODEL-DETAILS-REVISED OVERLEAF PACKAGE

Main manuscript: main.tex
Figures: figures/
Supplementary data: supplementary/
Corrected notebook: analysis_notebook/

Changes:
- Expanded sparse logistic regression model formulation and implementation.
- Expanded SHAP attribution formulation and reference distribution description.
- Expanded FOL/ILP algorithm: knowledge-base predicates, discretisation, candidate rules, beam search, coverage/precision constraints, score, sequential covering, held-out evaluation.
- Added feature-stability figure referenced in the manuscript from the corrected CSV.
- Included corrected analysis outputs and notebook.

Before submission:
- Verify reported metrics against the final notebook run.
- Confirm author/funding/ethics statements.
- Deposit code and derived outputs and add a public repository accession.
- Check journal formatting requirements.
